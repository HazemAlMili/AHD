# Khadematy — Local Prototype

Arabic RTL clickable prototype for Khadematy (خادمتي), including the transfer matching funnel, two-step form, thank-you state, homepage, worker catalogue, worker profile, and help-me-find flow.

## Requirements

- Node.js 18+
- pnpm 9+

## Run locally

```bash
pnpm install
pnpm --filter @workspace/mockup-sandbox run dev
```

Open the local URL shown by Vite, usually `http://localhost:5173/`.

## Build a production bundle

```bash
pnpm --filter @workspace/mockup-sandbox run build
```

The output will be created in `artifacts/mockup-sandbox/dist/`.

## Main file to continue editing

`artifacts/mockup-sandbox/src/components/mockups/khadematy/KhadematyPrototype.tsx`

The prototype uses local mock state only. WhatsApp handoffs use a fictional configuration value and should be replaced with the approved business number before production use.
